#include <iostream>
#include <map>
#include <string>
#include <vector>

std::map<std::string, int> ageMap;
std::map<std::string, std::string> nationMap;
std::vector<std::string> nameList;
std::vector<int> ageList;
std::vector<std::string> nationList;

int main() {
	int n = 0, option = 0;
	std::string name, nationality;
	int age = 0;
	std::cin >> n;
	for (int i = 1; i <= n; ++i) {
		cin >> name >> age >> nationality;
		nameList.push_back(name);
		ageList.push_back(age);
		nationList.push_back(nationality);
		ageMap[name] = age;
		nationMap[name] = nationality;
	}
	std::cin >> option;
	while (option != 4) {
		if (option == 1) {
			std::cin >> name;
			std::cout << ageMap[name] << std::endl;
		} else if (option == 2) {
			std::cin >> name;
			std::cout << nationMap[name] << std::endl;
		} else if (option == 3) {
			for (int i = 0; i < n; ++i) {
				std::cout << nameList[i] << " ";
				std::cout << ageList[i] << " ";
				std::cout << nationList[i] << std::endl;
			}
		}
		std::cin >> option;
	}
}