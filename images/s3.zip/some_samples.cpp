#include <vector>
#include <iostream>
#include <string>

std::vector<int> myVector;

int main() {
	std::string b, c;
	
	b = "Hello";
	c = "World";
	std::cout << b + c << std::endl;
	int a = 0; std::cin >> a;
	myVector.push_back(a);
	std::cout << *myVector.begin() << std::endl;
	myVector[0];
	myVector[myVector.size() - 1];
	std::vector<int>::iterator i = myVector.end();
	--i;

	// std::cout << myVector.end() << std::endl;
	// myVector.pop_back();
	myVector[0]
	for (auto i : myVector)
	for (int i = 0; i < myVector.size(); ++i)
	for (std::vector<int>::iterator i = myVector.begin();
		 i != myVector.end();
		 ++i)
}