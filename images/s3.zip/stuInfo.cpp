#include <iostream>
#include <map>
#include <string>
#include <vector>
#include <tuple>

using namespace std;



map<string, int> ageMap;
map<string, string> nationMap;
vector<string> nameList;
vector<int> ageList;
vector<string> nationList;

int main() {
	int n = 0, option = 0;
	string name, nationality;
	int age = 0;
	cin >> n;
	for (int i = 1; i <= n; ++i) {
		cin >> name >> age >> nationality;
		nameList.push_back(name);
		ageList.push_back(age);
		nationList.push_back(nationality);
		ageMap[name] = age;
		nationMap[name] = nationality;
	}
	cin >> option;
	while (option != 4) {
		if (option == 1) {
			cin >> name;
			cout << ageMap[name] << endl;
		} else if (option == 2) {
			cin >> name;
			cout << nationMap[name] << endl;
		} else if (option == 3) {
			for (int i = 0; i < n; ++i) {
				cout << nameList[i] << " ";
				cout << ageList[i] << " ";
				cout << nationList[i] << endl;
			}
		}
		cin >> option;
	}

}