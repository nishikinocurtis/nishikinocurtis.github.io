#include <iostream>

int main() {
	int integerList[5] = {0, 0, 0, 0, 0};
	int index = 0;
	std::cout << "Please input the first number:";
	std::cin >> integerList[0];
	std::cout << "Please input the second number:";
	std::cin >> integerList[1];
	std::cout << "Please input the third number:";
	std::cin >> integerList[2];
	std::cout << "Please input the fourth number:";
	std::cin >> integerList[3];
	std::cout << "Please input the fifth number:";
	std::cin >> integerList[4];
	std::cout << "Please select an index(1-5) to show:";
	std::cin >> index;
	std::cout << integerList[index - 1] << std::endl;
	return 0;
}