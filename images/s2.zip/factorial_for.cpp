#include <iostream>

int main() {
	int n = 0, product = 1;
	std::cin >> n;
	for (int i = 1; i <= n; ++i) {
		product *= i;
		//or product = product * i;
	}
	std::cout << product << std::endl;
	return 0;
}