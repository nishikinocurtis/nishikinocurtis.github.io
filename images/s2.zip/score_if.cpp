#include <iostream>

int main() {
	unsigned int rawScore = 0;
	char letterScore = 0;
	std::cin >> rawScore;
	if (rawScore >= 1000) {
		letterScore = 'A';
	} else if (rawScore >= 500 && rawScore <= 999) {
		//Actually, the "<=999" can be deleted,
		//Since rawScore does not satisfy the standard ">=1000".
		letterScore = 'B';
	} else if (rawScore >= 100 && rawScore <= 499) {
		letterScore = 'C';
	} else if (rawScore >= 50 && rawScore <= 99) {
		letterScore = 'D';
	} else if (rawScore >= 10 && rawScore <= 49) {
		letterScore = 'E';
	} else {
		letterScore = 'F';
	}
	std::cout << letterScore << std::endl;
	return 0;
}