#include <iostream>

using namespace std;

int main() {
	int v = 1000;
	if (v >= 1000) {
		cout << "notice 1" << endl;
	} else if (v >= 500) {
		cout << "notice 2" << endl;
	}
	return 0;
}