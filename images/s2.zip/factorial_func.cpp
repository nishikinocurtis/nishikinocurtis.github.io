#include <iostream>

int factorial(int n);

int main() {
	int inputN = 0;
	std::cin >> inputN;
	std::cout << factorial(inputN) << std::endl;
	return 0;
}

int factorial(int n) {
	if (n == 0 || n == 1) {
		return 1;
	}
	int product = n * factorial(n - 1);
	return product;
}
/* A much simpler implementation:
int factorial(int n) {
	if (n <= 1) return 1;
	return n * factorial(n - 1);
}
*/

