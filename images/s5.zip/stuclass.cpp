class stuInfo {
private:
	string name;
	int age;
	string nationality;
public:
	void modifyInfo(string tempName, int tempAge, string tempNation) {
		if (tempAge < 0) {
			cerr << "Negative Age." << endl;
			return;
			//this can be replaced by an exception like:
			throw NegativeAgeError //or things like that.
		}
		name = tempName;
		age = tempAge;
		nationality = tempNation
	}
	void printInfo() {
		cout << name << " " << age << " " << nationality << endl;
	}
}