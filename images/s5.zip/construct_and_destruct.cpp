class myType {
private:
	int var1, var2;
public:
	myType(int v1 = 0, int v2 = 1) : var(v1), var(v2) {
		cout << "construction 1 is activated" << endl;
		//var1 = v1;
		//var2 = v2;
		//both styles are OK.
	}
	myType(double v1 = 0.0, double v2 = 1.0) {
		cout << "construction 2 is activated" << endl;
		var1 = (int)floor(v1);
		var2 = (int)floor(v2);
	}
	~myType() {
		cout << "this item is being destructed" << endl;
	}

};
void function(int v1, int v2) {
	myType object = myType(v1, v2);
	cout << v1 << " " << v2;
	return;
}

int main() {
	function(1, 2);
}
