#include <iostream>

using std::cout;
using std::endl;

void function1(int para1) {
	para1 = 2021;
}
void function2(int &para1) {
	para1 = 2021;
}
void function3(int *ptr) {
	*ptr = 2021;
}

int main() {
	int var = 2020;
	cout << var << endl;
	function1(var); //you may modify the number, and try different functions
	cout << var << endl;
}