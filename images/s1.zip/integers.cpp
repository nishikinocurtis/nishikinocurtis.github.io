#include <iostream>

int main() {
	int a = 0;
	int b = 0;
	std::cout << "Welcome to use the program!" << std::endl;
	std::cout << "Now please input 2 integers:";
	std::cin >> a >> b;
	std::cout << ((a > b) ? a : b) << std::endl; //selection operator
	std::cout << (a + b) << std::endl;
	return 0;
}
/*
12 13
*/