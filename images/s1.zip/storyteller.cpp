#include <iostream>

int main() {
	std::cout << "Hello World!" << std::endl;
	std::cout << "HelloWorld";
	std::cout << std::endl;
	std::cout << "Welcome to the C++ Bootcamp." << std::endl;
	std::cout << "I am interested in programming." << std::endl;
	return 0;
}