#include <iostream>

int main() {
	char a = 0;
	char b = 0;
	std::cout << "Please input 2 seperated letters:";
	std::cin >> a >> b;
	std::cerr << a << b << std::endl;
	std::cerr << (int)a << " " << (int)b << std::endl; //adhidhiueVHGR
/*
CHVUIHVIUEWV
IUUCUGEWUHVUIE
IUFGwviuV
*/
	return 0;
}